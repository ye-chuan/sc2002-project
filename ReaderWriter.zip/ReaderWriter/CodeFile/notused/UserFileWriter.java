public abstract class UserFileWriter {

	/**
	 * 
	 * @param listOfallSpecifiedUser
	 */
	public boolean writeToUserFile(ArrayList<User> listOfallSpecifiedUser) {
		// TODO - implement UserFileWriter.writeToUserFile
		throw new UnsupportedOperationException();
	}

}