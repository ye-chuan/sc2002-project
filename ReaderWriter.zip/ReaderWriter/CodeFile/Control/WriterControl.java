import java.util.ArrayList;

/**
 * Principle demonstrated
 * Single Responsibility Principle: Different type of file reader to read different type of files.
 */
public class WriterControl {

	/**
	 * 
	 * @param listOfStudents
	 */
	public boolean storeStudents(ArrayList<Student> listOfStudents) {
		StudentFileWriter writeStudents = new StudentFileWriter();
		return writeStudents.writeToStudentFile(listOfStudents);
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param campList
	 */
	public boolean storeCamps(ArrayList<Camp> campList) {
		CampFileWriter writeCamps = new CampFileWriter();
		return writeCamps.writeToCampFile(campList);
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param listOfStaff
	 */
	public boolean storeStaff(ArrayList<Staff> listOfStaff) {
		StaffFileWriter writeStaff = new StaffFileWriter();
		return writeStaff.writeToStaffFile(listOfStaff);
		throw new UnsupportedOperationException();
	}

}