import java.util.ArrayList;
/**
 * Principle demonstrated
 * Single Responsibility Principle: Different type of file reader to read different type of files.
 */
public class ReaderControl {

	/**
	 * 
	 * @param fileTypeReader
	 */
	public ArrayList<Student> getStudents() {
		StudentFileReader readStudents = new StudentFileReader();
		return readStudents.readAllStudents();
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param fileTypeReader
	 */
	public ArrayList<Camp> getCamps() {
		CampFileReader readCamps = new CampFileReader();
		return readCamps.readAllCamps();
		throw new UnsupportedOperationException();
	}

	public ArrayList<Staff> getStaff() {
		StaffFileReader readStaff = new StaffFileReader();
		return readStaff.readAllStaff();
		throw new UnsupportedOperationException();
	}

}