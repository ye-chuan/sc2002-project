import java.util.ArrayList;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;;

public class StaffFileReader {

	public ArrayList<Staff> readAllStaff() {
try{	FileInputStream fisStaff = new FileInputStream("Staff.ser");
		ObjectInputStream oisStaff = new ObjectInputStream(fisStaff);

		ArrayLilst<Staff> listOfCurStaff = new ArrayList<Staff>();
		listOfCurStaff = (ArrayLilst<Staff>) oisStaff.readObject();
		return listOfCurStaff;
	}
catch (Exception e) {
		System.out.println("Unable to read file");
	}
		// TODO - implement StaffFileReader.readAllStaff
		throw new UnsupportedOperationException();
	}
}