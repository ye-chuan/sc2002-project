import java.util.ArrayList;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class CampFileReader {

	public ArrayList<Camp> readAllCamps() {
try{	FileInputStream fisCamp = new FileInputStream("Camp.ser");
		ObjectInputStream oisCamp = new ObjectInputStream(fisCamp);

		ArrayLilst<Camp> listOfCurCamp = new ArrayList<Camp>();
		listOfCurCamp = (ArrayLilst<Camp>) oisCamp.readObject();
		return listOfCurCamp;
	}
catch (Exception e) {
		System.out.println("Unable to read file");
	}
		// TODO - implement CampFileReader.readAllCamps
		throw new UnsupportedOperationException();
	}

}