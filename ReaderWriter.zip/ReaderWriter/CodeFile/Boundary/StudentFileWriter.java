import java.util.ArrayList;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class StudentFileWriter {

	/**
	 * 
	 * @param listOfStudent
	 */
	public boolean writeToStudentFile(ArrayList<Student> listOfStudent) {
		//FileOutputStream - writes to a file
		//ObjectOutputStream - Used to seralise objects -> take seralised object -> convert them into a sequence of byte that can be written into a file 
		//Seralisation is to convert object into a form that could be transported
		// Classes should implment seralisation if its object is going to be written into a fil.
	try {FileOutputStream fosWriteStudent = new FileOutputStream("Student.ser");
		ObjectOutputStream oosWriteStudent = new ObjectOutputStream(fosWriteStudent);
		oosWriteStudent(listOfStudent);
		oosWriteStudent.close();
		fosWriteStudent.close();
		return true;
		}
	catch (Exception e) {
		return false;
	}
		throw new UnsupportedOperationException();
	}
}