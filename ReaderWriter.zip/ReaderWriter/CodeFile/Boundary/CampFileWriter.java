import java.util.ArrayList;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class CampFileWriter {

	/**
	 * 
	 * @param allCamps
	 */
	public boolean writeToCampFile(ArrayList<Camp> allCamps) {
		//FileOutputStream - writes to a file
		//ObjectOutputStream - Used to seralise objects -> take seralised object -> convert them into a sequence of byte that can be written into a file 
		//Seralisation is to convert object into a form that could be transported
		// Classes should implment seralisation if its object is going to be written into a fil.
	try {FileOutputStream fosWriteCamp = new FileOutputStream("Camp.ser");
		ObjectOutputStream oosWriteCamp = new ObjectOutputStream(fosWriteCamp);
		oosWriteStudent(allCamps);
		oosWriteCamp.close();
		fosWriteCamp.close();
		return true;
		}
	catch (Exception e) {
		return false;
	}
		// TODO - implement CampFileWriter.writeToCampFile
		throw new UnsupportedOperationException();
	}

}