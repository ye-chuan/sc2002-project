/**
 * Not Sure who is going to call this class...
 * 
 * So How this works would be
 * 1) Get the input file
 * 2) Build the student/staff object using the input file -> There are missing attributes, Missing attributes will be initialised to NULL first.
 * 3) Write the object into the respective studentFile and stuffFile
 */
//To discuss if want to use DIP but how to do that as well
import java.util.ArrayList;
import java.util.Iterator;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class UserInputFileAllocator {

	private WriterControl writer;
	private ArrayList<Student> listOfStudents;
	private String defaultpw = "password";
	private ArrayList<Staff> listOfStaff;
	/**
	 * 
	 * @param inputFile
	 */
	public void intialiseStudentFile(File inputFile) {
		try {
			//Reading raw byte
			// Can use file reader also if wanna just read directly ig
			FileInputStream fStudent = new FileInputStream(inputFile);

			// Use Apache POI (Poor Obfuscation Implementation) for reading .xlsx
			// It provide two implmentation for reading .xlsx file
			// We are going to use XSSF (XML SpreadSheet Format) Implementation

			//First, create Student workbook Object 
			XSSFWorkbook studentWorkbook = new XSSFWorkbook(fStudent);
			//Get the first sheet of the workbook
			XSSFSheet studentSheet = studentWorkbook.getSheetAt(0);

			//Iterate rows
			//Iterator interface is not a data structure unlike arraylist.
			//It allows us to navigate through any data structure in forward direction
			Iterator<Row> rowIt = studentSheet.iterator();

			//Create array list of students
			//By default attributes of student is either null or 0 
			listOfStudents = new ArrayList<Student>();

			while(rowIt.hasNext()) {
				Student newStudent = new Student();
				Row row = rowIt.next();
				//Since we know that each col 1 = Name, col2 = email, col3 = faculty
				newStudent.name = row.getCell(0).toString();
				newStudent.email = row.getCell(1).toString();
				//Fauclty is an enum obj, as such we will use valueof() to convert string to enum obj
			try {
				newStudent.faculty = Faculty.valueof(row.getCell(2).toString());
				listOfStudents.addd(newStudent);
				}
			catch (IllegalArgumentException ie) {
				System.out.println("invalid faculty at row " + row.getRowNum());
			}
			}
		}
		catch(Exception e)  
        {  
        e.printStackTrace();  
        }
		
		//Write object into file by calling the writer obj with its corresponding method
		writer.storeStudents(listOfStudents);

	}

	/**
	 * 
	 * @param inputFile
	 */
	//For staff files, we do the same like for students.
	public void initialiseStaffFile(File inputFile) {
		try {
			FileInputStream fStaff = new FileInputStream(inputFile);
			XSSFWorkbook staffWorkbook = new XSSFWorkbook(fStaff);
			XSSFSheet staffSheet = staffWorkbook.getSheetAt(0);
			//Iterate row of the sheet
			Iterator<Row> rowIt = staffSheet.iterator();

			//Create array list of staff
			//By default attributes of staff is either null or 0 
			listOfStaff = new ArrayList<Staff>();

			while(rowIt.hasNext()) {
				Staff newStaff = new Staff();
				Row row = rowIt.next();
				//Since we know that each col 1 = Name, col2 = email, col3 = faculty
				newStaff.name = row.getCell(0).toString();
				newStaff.email = row.getCell(1).toString();
				//Fauclty is an enum obj, as such we will use valueof() to convert string to enum obj
			try {
				newStaff.faculty = Faculty.valueof(row.getCell(2).toString());
				listOfStaff.addd(newStaff);
				}
			catch (IllegalArgumentException ie) {
				System.out.println("invalid faculty at row " + row.getRowNum());
			}
			}
		}
		catch(Exception e)  
        {  
        e.printStackTrace();  
        }  
		throw new UnsupportedOperationException();
		//Write object into file by calling the writer obj with its corresponding method
		writer.storeStudents(listOfStaff);
	}
}