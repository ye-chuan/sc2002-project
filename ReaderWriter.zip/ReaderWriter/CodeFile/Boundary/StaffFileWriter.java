import java.util.ArrayList;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class StaffFileWriter {

	/**
	 * 
	 * @param listOfStaff
	 */
	public boolean writeToStaffFile(ArrayList<Staff> listOfStaff) {
		//FileOutputStream - writes to a file
		//ObjectOutputStream - Used to seralise objects -> take seralised object -> convert them into a sequence of byte that can be written into a file 
		//Seralisation is to convert object into a form that could be transported
		// Classes should implment seralisation if its object is going to be written into a fil.
	try {FileOutputStream fosWriteStaff = new FileOutputStream("Staff.ser");
		ObjectOutputStream oosWriteStaff = new ObjectOutputStream(fosWriteStaff);
		oosWriteStudent(listOfStaff);
		oosWriteStaff.close();
		fosWriteStaff.close();
		return true;
		}
	catch (Exception e) {
		return false;
	}
		// TODO - implement StaffFileWriter.writeToUserFile
		throw new UnsupportedOperationException();
	}
}