import java.util.ArrayList;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class StudentFileReader {

	public ArrayList<Student> readAllStudents() {
try{	FileInputStream fisStaff = new FileInputStream("Staff.ser");
		ObjectInputStream oisStaff = new ObjectInputStream(fisStaff);

		ArrayLilst<Student> listOfCurStaff = new ArrayList<Student>();
		listOfCurStaff = (ArrayLilst<Student>) oisStaff.readObject();
		return listOfCurStudent;
	}
catch (Exception e) {
		System.out.println("Unable to read file");
	}
		// TODO - implement StudentFileReader.readAllStudents
		throw new UnsupportedOperationException();
	}
}